"""OmicVerse web launcher package."""
